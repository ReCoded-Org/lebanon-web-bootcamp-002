function squareNumber(n) {
  console.log(`The result of squaring ${n} is ${n * n}`);
  return n * n;
}
function halfNumber(n) {
  console.log(`Half of ${n} is ${n / 2}`);
  return n / 2;
}
function percentOf(n1, n2) {
  console.log(`${n1} is ${(n1 * 100) / n2} of ${n2}`);
  return (n1 * 100) / n2;
}
function areaOfCircle(r) {
  console.log(`The area of a circle with radius ${r} is ${Math.PI * r * r}`);
  return Math.PI * r * r;
}
function operate(n) {
  let nHalf = n / 2;
  let nSquared = nHalf * nHalf;
  let nArea = Math.PI * nSquared * nSquared;
  let nPer = (nArea * 100) / nSquared;
}

let squareBtn = document.querySelector("#square-button");
let squareInput = document.getElementById("square-input");
squareBtn.addEventListener("click", (e) => {
  squareInput.value = squareNumber(squareInput.value);
});

let halfBtn = document.querySelector("#half-button");
let halfInput = document.getElementById("half-input");
halfBtn.addEventListener("click", (e) => {
  halfInput.value = halfNumber(halfInput.value);
});

let perBtn = document.querySelector("#percent-button");
let perInput1 = document.getElementById("percent1-input");
let perInput2 = document.getElementById("percent2-input");
perBtn.addEventListener("click", (e) => {
  perInput1.value = percentOf(perInput1.value, perInput2.value);
  perInput2.value = "";
});

let areaBtn = document.querySelector("#area-button");
let areaInput = document.getElementById("area-input");
areaBtn.addEventListener("click", (e) => {
  areaInput.value = areaOfCircle(areaInput.value);
});
